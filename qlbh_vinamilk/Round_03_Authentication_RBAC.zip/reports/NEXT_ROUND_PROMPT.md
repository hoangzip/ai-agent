# PROMPT KHỞI ĐỘNG ROUND 04 — EXCEL IMPORT, STAGING & BATCH VALIDATION

**Dự án:** Quản lý & Đối soát Tồn kho (Vinamilk)  
**Round tiếp theo:** 04/10  
**Owner:** Data Engineer + Backend Developer  
**Reviewer:** QC Reviewer (Độc lập)  
**Verifier:** QA Tester (Độc lập)  
**Coordinator:** Orchestrator  
**Ngôn ngữ:** Tiếng Việt 100%  

---

## 1. MỤC TIÊU ROUND 04

Triển khai quy trình Nạp file Excel kiểm kê thực tế (cả 4 file chuẩn và các file tải lên thủ công), xác thực toàn vẹn 15 cột, cơ chế Staging $\rightarrow$ Completed và kiểm soát chống trùng lặp (Idempotency):
1. **Parser Excel 15 cột:** Đọc file `.xlsx`, trích xuất thông tin Sheet `Kiem-ke`, xử lý 432–434 dòng sản phẩm, bảo toàn số 0 ở đầu mã SKU.
2. **Đối chiếu Dòng Tổng hợp (Dòng 2):** So khớp tổng số lượng và tổng thành tiền thực tế với Dòng 2; nếu lệch dù chỉ 1 đồng hoặc 1 sản phẩm $\rightarrow$ từ chối nạp và báo lỗi chi tiết.
3. **Cơ chế Staging $\rightarrow$ Completed:** Dữ liệu mới nạp mặc định ở trạng thái `STAGING`. Chỉ khi toàn bộ các dòng sản phẩm và ràng buộc hợp lệ mới atomic commit sang `COMPLETED`.
4. **Idempotency & Deduplication:** Băm `file_sha256` và `content_hash` để chống nạp trùng; cảnh báo `CONFLICT` nếu trùng mã kiểm kê nhưng dữ liệu bị chỉnh sửa.
5. **Giao diện Nạp File Excel:** Kéo thả nhiều file, xem trước dữ liệu (Preview), chỉnh sửa metadata (ngày/giờ/ca/loại kho).
6. **Kiểm thử tự động:** Nạp thử thành công cả 4 file nguồn thực tế (339000, 339513, 339931, 340231).

---

## 2. NỘI DUNG PROMPT GỬI CHO AGENT

```markdown
Bạn là Data Engineer và Backend Developer (dưới sự điều phối của Orchestrator) của dự án Inventory Management.
Round 03 (Authentication & RBAC) đã PASS với 60/60 test cases đạt 100%.
Hãy bắt đầu thực hiện Round 04/10: Excel Import, Manual Upload, Staging & Batch Validation.

Nhiệm vụ chính:
1. Triển khai API Import Excel:
   - `POST /api/v1/inventory/upload`: Nhận file Excel (hoặc payload JSON đã chuẩn hóa), validate 15 cột.
   - `GET /api/v1/inventory/staging`: Danh sách chứng từ đang ở trạng thái STAGING.
   - `POST /api/v1/inventory/commit/:id`: Chuyển trạng thái từ STAGING sang COMPLETED sau khi đối chiếu hợp lệ.
2. Deduplication & Idempotency:
   - Xử lý file trùng SHA256 (ALREADY_IMPORTED) và trùng dữ liệu (DUPLICATE).
   - Phát hiện xung đột (CONFLICT) khi trùng mã kiểm kê nhưng khác dữ liệu.
3. Đối chiếu Dòng 2:
   - So khớp sum(quantity) = Dòng 2 Cột 5.
   - So khớp sum(total_amount) = Dòng 2 Cột 8.
4. Giao diện Nhập File Excel (Frontend):
   - Kéo-thả .xlsx, preview bảng, báo lỗi theo dòng/cột nếu có sai phạm.
5. Kiểm thử QA:
   - Test nạp thành công 4 file thật: 339000, 339513, 339931, 340231.
   - Test từ chối file sai format, file thiếu cột, file sai số liệu dòng 2.
6. QC rà soát độc lập và đóng gói kết quả Round 04 vào 01 ZIP kèm file SHA256 ngoài ZIP.

Dừng lại sau khi báo cáo kết quả Round 04 để người dùng review trước khi chuyển Round 05.
```
