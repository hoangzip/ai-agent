# BÁO CÁO KIỂM THỬ CHẤT LƯỢNG ROUND 03 (TEST REPORT - MVP SCOPE)

**Dự án:** Quản lý & Đối soát Tồn kho (Vinamilk)  
**Round:** 03/10 – Authentication, Admin Bootstrap & User Management (RBAC)  
**Phạm vi kiểm thử:** Simplified Acceptance Scope (MVP)  
**Thời điểm thực thi:** 11/10/2026 18:35:00 +07:00  
**Hệ điều hành / Runtime:** Darwin (macOS arm64) / Node.js v20.18.0 / Python 3.11.0  
**Kết quả tổng thể:** **71/71 TEST CASES ĐẠT (100% PASS)**  

---

## 1. MA TRẬN KIỂM THỬ BẢO MẬT & HỆ THỐNG MVP (71 TESTS)

| Nhóm chức năng | Test Case | Mục tiêu kiểm thử | Kết quả |
|---|---|---|:---:|
| **Mã hóa PBKDF2** | `PBKDF2: hashPassword format` | 100.000 vòng lặp, salt 16-byte ngẫu nhiên, định dạng `pbkdf2:100000:<salt>:<hash>` | **PASS** |
| **Mã hóa PBKDF2** | `PBKDF2: distinct salts` | Hai lần băm cùng một mật khẩu sinh ra 2 salt và 2 chuỗi hash hoàn toàn khác nhau | **PASS** |
| **Mã hóa PBKDF2** | `PBKDF2: verifyPassword` | So khớp constant-time comparison: đúng = true, sai = false | **PASS** |
| **Bootstrap P0** | `SECURITY: Login does not auto-bootstrap` | Login trên DB trống không tự sinh Admin, trả về 401 an toàn | **PASS** |
| **Bootstrap P0** | `SECURITY: Bootstrap BLOCKED if token unconfigured` | `POST /api/v1/system/bootstrap` thiếu `BOOTSTRAP_TOKEN` bị chặn với HTTP 403 `BOOTSTRAP_DISABLED` | **PASS** |
| **Bootstrap P0** | `SECURITY: Bootstrap REJECTED if token wrong` | `POST /api/v1/system/bootstrap` sai token bị từ chối với HTTP 401 `INVALID_BOOTSTRAP_TOKEN` | **PASS** |
| **Bootstrap P0** | `POST /api/v1/system/bootstrap: rejects weak pass` | Chặn khởi tạo Admin với mật khẩu nằm trong blacklist (`123456`) | **PASS** |
| **Bootstrap P0** | `POST /api/v1/system/bootstrap: valid token & pass` | Khởi tạo thành công Admin duy nhất với mật khẩu mạnh, gắn `must_change_password=1` | **PASS** |
| **Bootstrap P0** | `SECURITY: Subsequent bootstrap call is BLOCKED` | Gọi bootstrap lần 2 bị chặn vĩnh viễn với HTTP 403 `BOOTSTRAP_ALREADY_COMPLETED` | **PASS** |
| **Anti-Enumeration** | `Login: wrong credentials generic error` | Tên đăng nhập sai hoặc mật khẩu sai đều trả về cùng một thông điệp lỗi 401 | **PASS** |
| **Rate Limiting** | `Rate Limiting: 5 failed attempts trigger 429` | Đăng nhập sai liên tiếp 5 lần $\rightarrow$ lần 6 trả về HTTP 429 `TOO_MANY_REQUESTS` kèm `Retry-After: 900` | **PASS** |
| **Đăng nhập & Phiên** | `Login admin with bootstrap password` | Đăng nhập thành công, cấp cookie HttpOnly và Bearer token | **PASS** |
| **Bảo vệ Cưỡng chế** | `Protected API blocks must_change_password=1` | Chặn 100% API nghiệp vụ nếu chưa đổi mật khẩu lần đầu (HTTP 403) | **PASS** |
| **Đổi Mật khẩu** | `Change password: valid strong pass` | Đổi mật khẩu thành công, mở khóa `must_change_password=0` | **PASS** |
| **CSRF Protection** | `CSRF REJECTION: Missing Origin` | Request dùng Cookie thiếu Origin/Referer bị chặn với HTTP 403 `CSRF_PROTECTION_FAILED` | **PASS** |
| **CSRF Protection** | `CSRF REJECTION: Untrusted Origin` | Request dùng Cookie có Origin lạ (`https://evil.com`) bị chặn HTTP 403 | **PASS** |
| **CSRF Protection** | `CSRF PASS: Trusted Origin` | Request dùng Cookie có Origin hợp lệ trong allowlist được chấp nhận | **PASS** |
| **CSRF Protection** | `CSRF BYPASS: Bearer Token M2M` | Request API dùng Bearer token không bị áp đặt kiểm tra Origin của browser | **PASS** |
| **Tạo Người dùng** | `Admin creates user with random strong pass` | Hệ thống tự sinh mật khẩu ngẫu nhiên an toàn, gắn cờ `must_change_password=1` | **PASS** |
| **Phân quyền RBAC** | `Standard user cannot call Admin endpoints` | Tài khoản USER gọi API quản trị bị chặn với HTTP 403 `FORBIDDEN_ADMIN_ONLY` | **PASS** |
| **Bảo vệ Deadlock** | `Cannot demote last active Admin` | Chặn hạ quyền Admin duy nhất xuống USER (HTTP 400 `CANNOT_DEMOTE_LAST_ADMIN`) | **PASS** |
| **Bảo vệ Deadlock** | `Cannot lock last active Admin` | Chặn khóa Admin duy nhất của hệ thống (HTTP 400 `CANNOT_LOCK_LAST_ADMIN`) | **PASS** |
| **Khóa & Revocation** | `Lock user revokes sessions immediately` | Khóa tài khoản nhân viên $\rightarrow$ toàn bộ phiên hoạt động lập tức bị thu hồi | **PASS** |
| **Anti-Enumeration** | `Locked account with wrong pass returns 401` | Mật khẩu sai trên tài khoản bị khóa trả về 401 (không tiết lộ trạng thái bị khóa) | **PASS** |
| **Anti-Enumeration** | `Locked account with correct pass returns 403` | Mật khẩu đúng trên tài khoản bị khóa mới trả về 403 `ACCOUNT_LOCKED` | **PASS** |
| **Đặt lại Mật khẩu** | `Admin resets password with auto random pass` | Sinh mật khẩu tạm mới, buộc đổi lần đầu, thu hồi toàn bộ phiên cũ | **PASS** |
| **Nhật ký Kiểm toán** | `AUDIT LOGS: security events recorded` | Bảng `audit_logs` ghi nhận đầy đủ bản ghi bootstrap, login, đổi pass, tạo user | **PASS** |
| **Đăng xuất an toàn** | `POST /api/v1/auth/logout` | Thu hồi phiên, xóa cookie HttpOnly, token cũ bị vô hiệu hóa | **PASS** |
| **Pytest Suite** | `tests/test_round_02.py + test_round_03.py` | 21 bài kiểm thử tự động Python (schema, ràng buộc CHECK, scan secrets) | **PASS** |

---

## 2. NHẬT KÝ THỰC THI KIỂM THỬ THỰC TẾ
```
$ npm test

> node --test apps/api/tests/*.test.js
ℹ tests 50
ℹ suites 0
ℹ pass 50
ℹ fail 0
ℹ duration_ms 877.592125

> python3 -m pytest tests/
tests/test_round_02.py ..............                                    [ 66%]
tests/test_round_03.py .......                                           [100%]
============================== 21 passed in 0.11s ==============================

TỔNG CỘNG: 71/71 TESTS PASS (100%).
```
