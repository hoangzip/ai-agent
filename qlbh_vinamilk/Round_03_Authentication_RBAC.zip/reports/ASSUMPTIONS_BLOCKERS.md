# DANH SÁCH GIẢ ĐỊNH & ĐIỂM CHẶN (ASSUMPTIONS & BLOCKERS - ROUND 03 FIX 01)

**Dự án:** Quản lý & Đối soát Tồn kho (Vinamilk)  
**Round:** 03/10 – Authentication, Admin Bootstrap & User Management (RBAC)  
**Ngày cập nhật:** 11/10/2026 (Fix 01)  

---

## 1. CÁC HẠNG MỤC ĐÃ HOÀN TẤT VÀ CHỐT TRONG ROUND 03 FIX 01

| Hạng mục | Quyết định đã thống nhất và triển khai | Trạng thái |
|---|---|:---:|
| **Admin Bootstrap An toàn (P0 Fix)** | Tách endpoint độc lập `POST /api/v1/system/bootstrap` với cơ chế guard một lần duy nhất. Không auto-bootstrap khi nhận request login. Xóa rò rỉ thông tin mật khẩu mẫu khỏi UI. | **HOÀN THÀNH (100% PASS)** |
| **Chính sách Mật khẩu Mạnh (P1 Fix)** | Loại bỏ hoàn toàn fallback `123456`. Mật khẩu tối thiểu 8 ký tự, blacklist mật khẩu thông dụng. Tự sinh mật khẩu ngẫu nhiên mạnh (12-16 ký tự). Modal copy an toàn trên UI. | **HOÀN THÀNH (100% PASS)** |
| **Rate Limiting / Brute-force (P1 Fix)** | Tối đa 5 lần đăng nhập sai trong 15 phút. Lần thứ 6 trả về HTTP 429 `TOO_MANY_REQUESTS` kèm `Retry-After: 900`. Tự động xóa bộ đếm khi đăng nhập đúng. | **HOÀN THÀNH (100% PASS)** |
| **CSRF & Origin Guard (P1 Fix)** | Xác minh Origin và Referer fail-closed đối với mọi phiên Cookie ở các unsafe methods (POST, PUT, PATCH, DELETE). Bỏ qua kiểm tra CSRF đối với Bearer Token M2M. | **HOÀN THÀNH (100% PASS)** |
| **Cookie Secure Fail-Safe (P2 Fix)** | Mặc định luôn bật cờ `; Secure` trừ khi môi trường được chỉ định rõ ràng là `development` hoặc `test`. | **HOÀN THÀNH (100% PASS)** |
| **Nhật ký Kiểm toán (P2 Fix)** | Ghi nhận bất biến vào bảng D1 `audit_logs` đối với toàn bộ hành vi: Bootstrap, Đăng nhập, Đăng xuất, Đổi mật khẩu, Tạo user, Khóa/mở khóa, Reset mật khẩu. | **HOÀN THÀNH (100% PASS)** |
| **Anti-Enumeration Nhất quán (P2 Fix)** | Xác thực mật khẩu PBKDF2 trước khi kiểm tra tài khoản bị khóa. Kẻ tấn công thử mật khẩu sai vào tài khoản bị khóa chỉ nhận 401 `INVALID_CREDENTIALS`. | **HOÀN THÀNH (100% PASS)** |
| **Cập nhật Hồ sơ & Chống Deadlock** | Thêm `PATCH /api/v1/users/:id`. Ngăn chặn cả việc khóa lẫn hạ quyền Admin duy nhất của hệ thống. | **HOÀN THÀNH (100% PASS)** |

---

## 2. KẾ HOẠCH BÀN GIAO CHO ROUND 04 (EXCEL IMPORT & STAGING)

| Hạng mục | Chi tiết kỹ thuật cần thực hiện ở Round 04 | Trách nhiệm |
|---|---|:---:|
| **Parser Excel Client-Side & API** | Đọc file `.xlsx`, trích xuất 15 cột, tính tổng tồn, thành tiền và đối chiếu với dòng tổng hợp Dòng 2. | Data Engineer |
| **Quy trình Staging $\rightarrow$ Completed** | Nạp dữ liệu vào bảng `inventory_files` với trạng thái ban đầu `STAGING`; chỉ chuyển `COMPLETED` khi toàn bộ 432–434 dòng sản phẩm hợp lệ 100%. | Data Engineer + Backend |
| **Idempotency & Chống Trùng lặp** | Tính toán cặp `file_sha256` và `content_hash` để phát hiện file đã nạp, file trùng nội dung, và cảnh báo `CONFLICT` nếu trùng mã khác số liệu. | Data Engineer |
| **Giao diện Nhập File Excel** | Kéo thả nhiều file Excel, xem trước dữ liệu (Preview), kiểm tra lỗi theo dòng/cột. | Frontend Developer |

---

## 3. ĐIỂM CHẶN HIỆN TẠI (BLOCKERS)

**KHÔNG CÓ ĐIỂM CHẶN (ZERO BLOCKERS)**. Cơ chế xác thực, bảo mật phiên và phân quyền RBAC đã sẵn sàng bảo vệ an toàn cho các nghiệp vụ nạp dữ liệu ở Round 04.
