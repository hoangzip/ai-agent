/**
 * Cloudflare Worker Entry Point: apps/api/src/index.ts
 * Nền tảng API REST quản lý và đối soát tồn kho (Revision 2 - Fix Review)
 */

import { handleCors, appendCorsHeaders } from "./middleware/cors.js";
import { createErrorResponse } from "./middleware/errorHandler.js";
import { handleHealthCheck } from "./routes/health.js";
import { handleSystemInfo, handleBootstrap } from "./routes/system.js";
import { handleUnimplementedModule } from "./routes/stubs.js";
import {
  handleLogin,
  handleLogout,
  handleChangePassword,
  handleGetMe
} from "./routes/auth.js";
import {
  handleListUsers,
  handleCreateUser,
  handleUpdateUser,
  handleUpdateUserStatus,
  handleResetPassword
} from "./routes/users.js";


export interface Env {
  DB?: any; // Cloudflare D1 Database binding
  ENVIRONMENT?: string;
  ROUND?: string;
  APP_TIMEZONE?: string;
  ALLOWED_ORIGINS?: string;
}

function sanitizeRequestId(rawId: string | null): string {
  if (!rawId) {
    return crypto.randomUUID();
  }
  const trimmed = rawId.trim();
  // Giới hạn độ dài <= 64 ký tự và chỉ chứa ký tự an toàn
  if (trimmed.length > 0 && trimmed.length <= 64 && /^[a-zA-Z0-9_\-]+$/.test(trimmed)) {
    return trimmed;
  }
  return crypto.randomUUID();
}

export default {
  async fetch(request: Request, env: Env, ctx: any): Promise<Response> {
    // 1. Xử lý CORS Preflight
    const corsResponse = handleCors(request, env);
    if (corsResponse) {
      return corsResponse;
    }

    const requestId = sanitizeRequestId(request.headers.get("X-Request-ID"));
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    let response: Response;

    try {
      // 2. Health check route
      if ((path === "/api/health" || path === "/health") && method === "GET") {
        response = handleHealthCheck(request, env, requestId);
      }
      // 3. System info route (Async kiểm tra kết nối D1 thực tế)
      else if (path === "/api/v1/system/info" && method === "GET") {
        response = await handleSystemInfo(request, env, requestId);
      }
      // 3b. System bootstrap route (Khởi tạo tài khoản Quản trị viên an toàn ban đầu)
      else if (path === "/api/v1/system/bootstrap" && method === "POST") {
        response = await handleBootstrap(request, env, requestId);
      }
      // 4. Đồng bộ route Snapshots (Xử lý cả /api/snapshots và /api/v1/snapshots)
      else if (
        (path === "/api/snapshots" || path.startsWith("/api/v1/snapshots") || path.startsWith("/api/v1/inventory"))
      ) {
        response = handleUnimplementedModule("Quản lý Chứng từ Kiểm kê (Snapshots)", "Round 04", requestId);
      }
      // 5. Authentication routes (Round 03)
      else if (path === "/api/v1/auth/login" && method === "POST") {
        response = await handleLogin(request, env, requestId);
      } else if (path === "/api/v1/auth/logout" && method === "POST") {
        response = await handleLogout(request, env, requestId);
      } else if (path === "/api/v1/auth/change-password" && method === "POST") {
        response = await handleChangePassword(request, env, requestId);
      } else if (path === "/api/v1/auth/me" && method === "GET") {
        response = await handleGetMe(request, env, requestId);
      }
      // 6. User Management routes (Round 03 - Admin only)
      else if (path === "/api/v1/users" && method === "GET") {
        response = await handleListUsers(request, env, requestId);
      } else if (path === "/api/v1/users" && method === "POST") {
        response = await handleCreateUser(request, env, requestId);
      } else if (/^\/api\/v1\/users\/(\d+)\/status$/.test(path) && method === "PATCH") {
        const match = path.match(/^\/api\/v1\/users\/(\d+)\/status$/);
        const targetUserId = parseInt(match![1], 10);
        response = await handleUpdateUserStatus(request, env, requestId, targetUserId);
      } else if (/^\/api\/v1\/users\/(\d+)$/.test(path) && method === "PATCH") {
        const match = path.match(/^\/api\/v1\/users\/(\d+)$/);
        const targetUserId = parseInt(match![1], 10);
        response = await handleUpdateUser(request, env, requestId, targetUserId);
      } else if (/^\/api\/v1\/users\/(\d+)\/reset-password$/.test(path) && method === "POST") {
        const match = path.match(/^\/api\/v1\/users\/(\d+)\/reset-password$/);
        const targetUserId = parseInt(match![1], 10);
        response = await handleResetPassword(request, env, requestId, targetUserId);
      }
 else if (path.startsWith("/api/v1/compare")) {
        response = handleUnimplementedModule("Động cơ Đối soát Tồn kho (Comparison Engine)", "Round 05", requestId);
      } else if (path.startsWith("/api/v1/history")) {
        response = handleUnimplementedModule("Lịch sử Biến động Sản phẩm (SKU History)", "Round 05", requestId);
      } else if (path.startsWith("/api/v1/sync")) {
        response = handleUnimplementedModule("Đồng bộ Google Drive", "Round 07", requestId);
      } else if (path.startsWith("/api/v1/export")) {
        response = handleUnimplementedModule("Xuất Báo cáo (XLSX/CSV)", "Round 08", requestId);
      }
      // 6. 404 Route Not Found
      else {
        response = createErrorResponse({
          status: 404,
          code: "NOT_FOUND",
          message: `Endpoint không tồn tại: ${method} ${path}`,
          requestId,
          env
        });
      }
    } catch (err: any) {
      // 7. Global Catch 500 (Ghi log console nội bộ, che giấu chi tiết trong response production)
      console.error(`[INTERNAL_ERROR][${requestId}]:`, err);
      response = createErrorResponse({
        status: 500,
        code: "INTERNAL_SERVER_ERROR",
        message: "Lỗi máy chủ nội bộ trong quá trình xử lý yêu cầu",
        details: err?.message || String(err),
        requestId,
        env
      });
    }

    // Luôn gắn header CORS và Request ID vào response
    response.headers.set("X-Request-ID", requestId);
    return appendCorsHeaders(response, request, env);
  }
};
