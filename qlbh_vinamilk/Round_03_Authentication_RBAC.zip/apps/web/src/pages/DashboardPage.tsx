import React from "react";
import { Package, TrendingDown, DollarSign, Files, ArrowUpRight, ArrowDownRight, AlertTriangle } from "lucide-react";
import { KpiCard } from "../components/KpiCard";

export const DashboardPage: React.FC = () => {
  // DỮ LIỆU MẪU MINH HỌA GIAO DIỆN (PREVIEW MOCKUP - CHƯA KẾT NỐI DATABASE THỰC TẾ)
  // Thời gian và ca kiểm kê được căn chỉnh theo đúng chứng từ nguồn:
  // - 339000: 00:52 (Đêm / Đầu ngày)
  // - 339513: 14:41 (Chiều)
  // - 339931: 21:03 (Tối)
  // - 340231: 14:06 (Chiều)
  const mockSnapshots = [
    {
      code: "KK.CH41551.26.340231",
      ticket: "340231",
      date: "11/10/2026",
      time: "14:06",
      shift: "Chiều",
      skuCount: 434,
      totalQty: "16.972",
      totalAmount: "273.775.891 đ",
      deltaQty: "-175"
    },
    {
      code: "KK.CH41551.26.339931",
      ticket: "339931",
      date: "10/10/2026",
      time: "21:03",
      shift: "Tối",
      skuCount: 434,
      totalQty: "17.147",
      totalAmount: "275.711.737 đ",
      deltaQty: "+57"
    },
    {
      code: "KK.CH41551.26.339513",
      ticket: "339513",
      date: "09/10/2026",
      time: "14:41",
      shift: "Chiều",
      skuCount: 432,
      totalQty: "17.090",
      totalAmount: "272.476.003 đ",
      deltaQty: "+129"
    },
    {
      code: "KK.CH41551.26.339000",
      ticket: "339000",
      date: "09/10/2026",
      time: "00:52",
      shift: "Khác",
      skuCount: 432,
      totalQty: "16.961",
      totalAmount: "270.739.477 đ",
      deltaQty: "Gốc"
    }
  ];

  return (
    <div className="space-y-6">
      {/* CẢNH BÁO MINH BẠCH: DỮ LIỆU MẪU PREVIEW */}
      <div className="bg-amber-50 border border-amber-200/80 rounded-xl p-4 flex items-start space-x-3.5 shadow-xs">
        <div className="p-2 rounded-lg bg-amber-100 text-amber-700 shrink-0 mt-0.5">
          <AlertTriangle className="w-4 h-4" />
        </div>
        <div className="flex-1">
          <div className="flex items-center space-x-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900">
              DỮ LIỆU MẪU (PREVIEW GIAO DIỆN) – CHƯA KẾT NỐI DATABASE THỰC TẾ
            </h4>
            <span className="text-[10px] px-2 py-0.5 bg-amber-200/60 text-amber-900 rounded font-semibold">
              Round 02 Foundation
            </span>
          </div>
          <p className="text-xs text-amber-800 mt-1 leading-relaxed">
            Các chỉ số KPI và bảng chứng từ dưới đây dùng để định hình giao diện và cấu trúc hiển thị.
            Hệ thống chưa thực hiện nạp dữ liệu động từ Cloudflare D1. Tính năng nạp và đọc dữ liệu thật sẽ được kết nối chính thức tại <strong>Round 04 (Excel Import & Management)</strong>.
          </p>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title="Tổng tồn kho mẫu (#340231)"
          value="16.972"
          subtitle="Đơn vị sản phẩm (Mẫu)"
          icon={Package}
          trend={{ value: "-175 (-1.02%)", isPositive: false }}
          iconBgColor="bg-blue-50 text-blue-600"
        />
        <KpiCard
          title="Tổng giá trị tồn mẫu (VND)"
          value="273.775.891 đ"
          subtitle="Theo giá sau VAT (Mẫu)"
          icon={DollarSign}
          trend={{ value: "-1.935.846 đ", isPositive: false }}
          iconBgColor="bg-emerald-50 text-emerald-600"
        />
        <KpiCard
          title="Số SKU theo dõi mẫu"
          value="434 SKU"
          subtitle="391 Bán + 43 KM (Mẫu)"
          icon={Files}
          iconBgColor="bg-purple-50 text-purple-600"
        />
        <KpiCard
          title="Biến động mẫu gần nhất"
          value="28 SKU giảm"
          subtitle="11/10 Chiều vs 10/10 Tối"
          icon={TrendingDown}
          iconBgColor="bg-amber-50 text-amber-600"
        />
      </div>

      {/* Mock Snapshots Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="font-bold text-slate-900 text-sm">Danh sách Chứng từ Kiểm kê (Bản xem trước mẫu)</h3>
              <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-medium">Mô phỏng UI</span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Minh họa bố cục bảng danh sách chứng từ trước khi tích hợp API Round 04</p>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 text-slate-600 border-b border-slate-100 uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3 px-4">Mã chứng từ</th>
                <th className="py-3 px-4">Ngày / Giờ / Ca</th>
                <th className="py-3 px-4 text-right">Số SKU</th>
                <th className="py-3 px-4 text-right">Tổng tồn</th>
                <th className="py-3 px-4 text-right">Tổng thành tiền (VND)</th>
                <th className="py-3 px-4 text-center">Biến động $\Delta$</th>
                <th className="py-3 px-4 text-center">Nguồn dữ liệu</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {mockSnapshots.map((s, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50 transition">
                  <td className="py-3 px-4 font-mono font-medium text-slate-900">
                    {s.code}
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-medium text-slate-900">{s.date}</span>
                    <span className="ml-1 text-slate-400">({s.time})</span>
                    <span className="ml-1.5 px-1.5 py-0.5 rounded text-[10px] bg-slate-100 text-slate-600 font-medium">
                      Ca {s.shift}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-medium">{s.skuCount}</td>
                  <td className="py-3 px-4 text-right font-semibold text-slate-900">{s.totalQty}</td>
                  <td className="py-3 px-4 text-right font-medium">{s.totalAmount}</td>
                  <td className="py-3 px-4 text-center">
                    {s.deltaQty.startsWith("+") ? (
                      <span className="inline-flex items-center text-emerald-600 font-semibold">
                        <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
                        {s.deltaQty}
                      </span>
                    ) : s.deltaQty.startsWith("-") ? (
                      <span className="inline-flex items-center text-rose-600 font-semibold">
                        <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />
                        {s.deltaQty}
                      </span>
                    ) : (
                      <span className="text-slate-500">{s.deltaQty}</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-100 text-amber-800">
                      Dữ liệu mẫu
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
