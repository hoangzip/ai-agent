/**
 * File: apps/web/src/api/client.ts
 * API Client kết nối Backend Cloudflare Workers
 */

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  meta?: Record<string, any>;
}

const RAW_BASE = import.meta.env?.VITE_API_BASE_URL as string | undefined;
export const API_BASE_URL = (RAW_BASE && RAW_BASE.trim() !== "" ? RAW_BASE.trim() : "/api").replace(/\/$/, "");

export async function fetchApi<T = any>(endpoint: string, options: RequestInit = {}): Promise<ApiResponse<T>> {
  const cleanEndpoint = endpoint.startsWith("/") ? endpoint : `/${endpoint}`;
  const url = `${API_BASE_URL}${cleanEndpoint}`;
  const headers = new Headers(options.headers || {});
  if (!headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  try {
    const res = await fetch(url, {
      credentials: "include",
      ...options,
      headers
    });
    const json = await res.json();
    return json;
  } catch (err: any) {
    return {
      success: false,
      error: {
        code: "NETWORK_ERROR",
        message: "Không thể kết nối đến máy chủ API: " + (err?.message || String(err))
      }
    };
  }
}

export const api = {
  getHealth: () => fetchApi("/health"),
  getSystemInfo: () => fetchApi("/v1/system/info"),

  // Auth APIs (Round 03)
  login: (credentials: { username: string; password: string }) =>
    fetchApi("/v1/auth/login", {
      method: "POST",
      body: JSON.stringify(credentials)
    }),
  logout: () =>
    fetchApi("/v1/auth/logout", {
      method: "POST"
    }),
  changePassword: (data: { current_password: string; new_password: string }) =>
    fetchApi("/v1/auth/change-password", {
      method: "POST",
      body: JSON.stringify(data)
    }),
  getMe: () => fetchApi("/v1/auth/me"),

  // User Management APIs (Round 03 - Admin Only)
  getUsers: () => fetchApi("/v1/users"),
  createUser: (userData: { username: string; password?: string; role?: string; full_name: string }) =>
    fetchApi("/v1/users", {
      method: "POST",
      body: JSON.stringify(userData)
    }),
  updateUser: (userId: number, data: { full_name?: string; role?: string }) =>
    fetchApi(`/v1/users/${userId}`, {
      method: "PATCH",
      body: JSON.stringify(data)
    }),
  updateUserStatus: (userId: number, is_active: boolean) =>
    fetchApi(`/v1/users/${userId}/status`, {
      method: "PATCH",
      body: JSON.stringify({ is_active })
    }),
  resetUserPassword: (userId: number, temp_password?: string) =>
    fetchApi(`/v1/users/${userId}/reset-password`, {
      method: "POST",
      body: JSON.stringify(temp_password ? { temp_password } : {})
    }),


  getSnapshots: (params: { page?: number; limit?: number; date?: string; store_code?: string } = {}) => {
    const query = new URLSearchParams();
    if (params.page) query.set("page", params.page.toString());
    if (params.limit) query.set("limit", params.limit.toString());
    if (params.date) query.set("date", params.date);
    if (params.store_code) query.set("store_code", params.store_code);
    return fetchApi(`/v1/snapshots?${query.toString()}`);
  }
};
