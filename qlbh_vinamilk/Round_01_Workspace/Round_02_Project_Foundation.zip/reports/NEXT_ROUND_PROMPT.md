# PROMPT KHỞI ĐỘNG ROUND 03 — AUTHENTICATION & USER MANAGEMENT

**Dự án:** Quản lý & Đối soát Tồn kho (Vinamilk)  
**Round tiếp theo:** 03/10  
**Owner:** Backend Developer + Security & DevOps  
**Reviewer:** QC Reviewer (Độc lập)  
**Verifier:** QA Tester (Độc lập)  
**Coordinator:** Orchestrator  
**Ngôn ngữ:** Tiếng Việt 100%  

---

## 1. MỤC TIÊU ROUND 03

Triển khai hoàn chỉnh hệ thống Xác thực (Authentication), Quản lý người dùng và Phân quyền (RBAC) trên nền tảng Cloudflare Workers & D1 Database đã thiết lập ở Round 02:
1. **Bootstrap Admin an toàn:** Tài khoản mặc định `admin` / mật khẩu tạm `123456` (chỉ dùng cho môi trường test local) và **bắt buộc đổi mật khẩu ngay ở lần đăng nhập đầu tiên** (`must_change_password = 1`).
2. **Thuật toán băm mật khẩu an toàn:** Có salt, chống brute-force, không dùng SHA-256 thuần túy.
3. **Quản lý Phiên (Sessions):** HttpOnly, Secure cookie hoặc Bearer Token, hỗ trợ thu hồi tức thì (revocation) khi Admin khóa tài khoản hoặc khi logout.
4. **Phân quyền RBAC:**
   - `ADMIN`: Quản lý người dùng, tạo/sửa/khóa user, reset mật khẩu, xóa mềm/khôi phục snapshot.
   - `USER`: Xem danh sách, import, so sánh tồn kho, xuất báo cáo, đổi mật khẩu cá nhân; gọi API xóa mềm hoặc API admin phải nhận phản hồi `403 Forbidden`.
   - Ngăn chặn khóa tài khoản Admin hoạt động cuối cùng.
5. **Giao diện người dùng:** Trang Đăng nhập, Modal/Trang Đổi mật khẩu bắt buộc lần đầu, Màn hình Quản lý người dùng (dành cho Admin) bằng tiếng Việt 100%.

---

## 2. NỘI DUNG PROMPT GỬI CHO AGENT

```markdown
Bạn là Backend Developer và Security Specialist (dưới sự điều phối của Orchestrator) của dự án Inventory Management.
Round 02 đã PASS với Project Foundation, Database D1 10 bảng và API Skeleton đã được nghiệm thu.
Hãy bắt đầu thực hiện Round 03/10: Authentication, Admin Bootstrap & User Management (RBAC).

Nhiệm vụ chính:
1. Triển khai API Authentication:
   - `POST /api/v1/auth/login` (rate-limit, chống enumeration)
   - `POST /api/v1/auth/logout` (revoke session)
   - `POST /api/v1/auth/change-password` (bắt buộc khi must_change_password=1)
   - `GET /api/v1/auth/me` (thông tin người dùng hiện tại)
2. Triển khai API User Management (Chỉ Admin):
   - `GET /api/v1/users` (danh sách người dùng)
   - `POST /api/v1/users` (tạo user mới)
   - `PATCH /api/v1/users/:id/status` (khóa/mở khóa, tự động revoke session khi khóa)
   - `POST /api/v1/users/:id/reset-password` (reset mật khẩu tạm)
   - Không cho phép khóa tài khoản Admin cuối cùng.
3. Middleware xác thực & RBAC:
   - Bảo vệ toàn bộ endpoint nhạy cảm, trả về 401 khi chưa đăng nhập, 403 khi USER truy cập tài nguyên ADMIN.
4. Frontend:
   - Trang Đăng nhập tiếng Việt
   - Modal Đổi mật khẩu bắt buộc lần đầu
   - Màn hình Quản lý người dùng trong AppShell
5. Kiểm thử tự động (QA):
   - Unit tests và Integration tests bao phủ: đăng nhập thành công, đăng nhập sai, đổi pass lần đầu, 403 khi USER gọi Admin API, revoke session khi user bị khóa.
6. QC rà soát độc lập và đóng gói kết quả Round 03 vào duy nhất 01 ZIP kèm file SHA256 ngoài ZIP.

Dừng lại sau khi báo cáo kết quả Round 03 để người dùng review trước khi chuyển Round 04.
```
