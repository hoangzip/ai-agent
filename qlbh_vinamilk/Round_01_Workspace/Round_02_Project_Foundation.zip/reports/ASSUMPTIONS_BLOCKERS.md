# DANH SÁCH GIẢ ĐỊNH & ĐIỂM CHẶN (ASSUMPTIONS & BLOCKERS - FIX 02)

**Dự án:** Quản lý & Đối soát Tồn kho (Vinamilk)  
**Round:** 02/10 – Project Foundation, Database & API (Fix 02: Security & Deployment Contract)  
**Ngày cập nhật:** 11/10/2026  

---

## 1. CÁC QUYẾT ĐỊNH THIẾT KẾ ĐÃ CHỐT TRONG FIX 02

| Hạng mục | Quyết định đã thống nhất và triển khai | Trạng thái |
|---|---|:---:|
| **Bảo mật CORS** | Chỉ cho phép EXACT origins trong allowlist cấu hình qua `ALLOWED_ORIGINS` (và localhost khi dev/test). Không dùng regex wildcard `*.pages.dev`/`*.workers.dev`. Luôn đính kèm `Vary: Origin`. Không xuất ACAO khi origin không hợp lệ. | **ĐÃ GIẢI QUYẾT TRIỆT ĐỂ** |
| **Xử lý lỗi Fail-Closed** | Mặc định Production-Safe (`details: null` cho lỗi 500) khi `ENVIRONMENT` thiếu hoặc khác explicit dev/test. `wrangler.toml` mặc định `ENVIRONMENT = "production"`. | **ĐÃ GIẢI QUYẾT TRIỆT ĐỂ** |
| **Hợp đồng kết nối UI - API** | Hỗ trợ 2 phương án: (1) `VITE_API_BASE_URL` động + `credentials: "include"`, (2) Cloudflare Pages `_routes.json` và Pages Function reverse proxy cho `/api/*` same-origin. | **ĐÃ GIẢI QUYẾT TRIỆT ĐỂ** |
| **Độ chính xác Tiền VND** | Các cột tiền tệ `total_amount_vnd`, `unit_price`, `total_amount` chuyển sang kiểu `INTEGER` nguyên bản trong SQLite D1, loại trừ rủi ro sai số số thực nhị phân. Các cột số lượng giữ `REAL`. | **ĐÃ CHỐT VÀ MIGRATION XONG** |

---

## 2. KẾ HOẠCH BÀN GIAO CHO CÁC ROUND TIẾP THEO

| Hạng mục | Chi tiết triển khai | Round phụ trách |
|---|---|:---:|
| **Bảo vệ Sessions với Token Hash** | Lưu SHA-256 / HMAC băm của token trong `sessions.id`, không lưu token bản rõ; triển khai cookie HttpOnly SameSite với CORS credentials đã cấu hình. | **Round 03** (Auth & Users) |
| **Import & Xác thực Dữ liệu Kế toán** | Xác thực 15 cột, làm tròn và ép kiểu số nguyên VND cho `total_amount_vnd`, chuyển trạng thái snapshot từ `STAGING` sang `COMPLETED`. | **Round 04** (Excel Import) |
| **Động cơ Đối soát Tồn kho** | So khớp sai lệch số lượng và thành tiền giữa các chứng từ kế tiếp. | **Round 05** (Reconciliation) |
| **Google Drive Connector** | Đồng bộ tự động theo dõi `(source_file_id, source_revision)` để chống duplicate. | **Round 07** (Drive Sync) |
| **Cloudflare Live Deployment** | Cấu hình Cloudflare D1 production database và Workers Secrets trên môi trường Cloudflare chính thức. | **Round 10** (Deployment) |

---

## 3. ĐIỂM CHẶN HIỆN TẠI (BLOCKERS)

**KHÔNG CÓ ĐIỂM CHẶN (ZERO BLOCKERS)**. Toàn bộ mã nguồn, cấu hình bảo mật, kiểm thử và tài liệu đã sẵn sàng đóng Gate Round 02.
