import { createSuccessResponse } from "../middleware/errorHandler.js";

export async function handleSystemInfo(request: Request, env: any, requestId: string): Promise<Response> {
  let dbStatus: "connected" | "not_configured" | "unavailable" = "not_configured";
  let dbMessage: string | undefined = "Chưa cấu hình D1 database binding trong môi trường hiện tại";

  if (env?.DB) {
    try {
      // Thực hiện kiểm tra kết nối D1 thực tế
      await env.DB.prepare("SELECT 1").first();
      dbStatus = "connected";
      dbMessage = undefined;
    } catch (err: any) {
      dbStatus = "unavailable";
      dbMessage = "D1 binding tồn tại nhưng không thể thực thi truy vấn kiểm tra";
    }
  }

  const systemData = {
    service: "inventory-management-backend",
    version: "0.2.0",
    round: "02/10 – Project Foundation, Database & API",
    environment: env?.ENVIRONMENT || "development",
    timezone: env?.APP_TIMEZONE || "Asia/Ho_Chi_Minh",
    timestamp: new Date().toISOString(),
    database: {
      provider: "Cloudflare D1 (SQLite Engine)",
      status: dbStatus,
      ...(dbMessage ? { message: dbMessage } : {})
    },
    modules: {
      auth: "ROUND_03_PLANNED",
      users: "ROUND_03_PLANNED",
      inventory_import: "ROUND_04_PLANNED",
      comparison_engine: "ROUND_05_PLANNED",
      product_history: "ROUND_05_PLANNED",
      ui_dashboard: "ROUND_06_PLANNED",
      gdrive_sync: "ROUND_07_PLANNED",
      soft_delete: "ROUND_08_PLANNED"
    },
    features: {
      multi_snapshot_per_day: "SUPPORTED",
      natural_key_enforcement: "SUPPORTED",
      leading_zero_sku_preservation: "SUPPORTED",
      soft_delete_foundation: "SUPPORTED",
      audit_logging_schema: "SUPPORTED",
      zod_contract_validation: "SUPPORTED"
    }
  };

  return createSuccessResponse(systemData, 200, { requestId });
}
