import React from "react";
import { Store, Bell, Layers } from "lucide-react";

interface HeaderProps {
  title: string;
  subtitle?: string;
}

export const Header: React.FC<HeaderProps> = ({ title, subtitle }) => {
  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between shrink-0">
      <div>
        <h2 className="text-lg font-bold text-slate-900 tracking-tight">{title}</h2>
        {subtitle && <p className="text-xs text-slate-500">{subtitle}</p>}
      </div>

      <div className="flex items-center space-x-4">
        {/* Store Indicator */}
        <div className="flex items-center space-x-2 px-3 py-1.5 bg-slate-100 rounded-lg text-xs font-medium text-slate-700">
          <Store className="w-3.5 h-3.5 text-slate-500" />
          <span>Chi nhánh: <strong className="text-slate-900">CH41551</strong></span>
        </div>

        {/* Chế độ nền tảng / Foundation Indicator minh bạch */}
        <div className="flex items-center space-x-1.5 px-2.5 py-1.5 bg-indigo-50 text-indigo-700 border border-indigo-200/60 rounded-lg text-xs font-medium">
          <Layers className="w-3.5 h-3.5 text-indigo-500" />
          <span>Round 02 Foundation</span>
        </div>

        {/* Notification icon */}
        <button className="p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors">
          <Bell className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
