import React, { useState } from "react";
import { Sidebar, NavItemKey } from "./Sidebar";
import { Header } from "./Header";
import { DashboardPage } from "../pages/DashboardPage";
import {
  SnapshotsPage,
  ImportPage,
  ComparePage,
  HistoryPage,
  SyncPage,
  UsersPage,
  TrashPage,
  SettingsPage
} from "../pages/OtherPages";

export const AppShell: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<NavItemKey>("dashboard");

  const tabTitles: Record<NavItemKey, { title: string; subtitle: string }> = {
    dashboard: {
      title: "Tổng quan Tồn kho",
      subtitle: "Bảng điều khiển theo dõi số liệu và biến động kiểm kê"
    },
    snapshots: {
      title: "Danh sách Chứng từ Kiểm kê",
      subtitle: "Tra cứu các đợt kiểm đếm theo ngày, ca và cửa hàng"
    },
    import: {
      title: "Nhập File Excel Kiểm kê",
      subtitle: "Nạp và chuẩn hóa dữ liệu từ file Excel .xlsx 15 cột"
    },
    compare: {
      title: "So sánh Đối soát Tồn kho",
      subtitle: "Phân tích chênh lệch số lượng và thành tiền giữa hai snapshot"
    },
    history: {
      title: "Lịch sử Biến động Sản phẩm",
      subtitle: "Theo dõi chuỗi thời gian tồn kho của từng SKU"
    },
    sync: {
      title: "Đồng bộ Google Drive",
      subtitle: "Cấu hình tự động quét folder và đối soát dữ liệu đám mây"
    },
    users: {
      title: "Quản lý Người dùng",
      subtitle: "Phân quyền và tài khoản hệ thống (Dành cho Quản trị viên)"
    },
    trash: {
      title: "Thùng rác & Phục hồi",
      subtitle: "Quản lý các snapshot đã xóa mềm (Soft Delete)"
    },
    settings: {
      title: "Cài đặt Hệ thống",
      subtitle: "Tham số kiểm kê, múi giờ và cấu hình vận hành"
    }
  };

  const currentInfo = tabTitles[currentTab];

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar navigation */}
      <Sidebar currentTab={currentTab} onTabChange={setCurrentTab} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header title={currentInfo.title} subtitle={currentInfo.subtitle} />

        <main className="flex-1 overflow-y-auto p-6">
          {currentTab === "dashboard" && <DashboardPage />}
          {currentTab === "snapshots" && <SnapshotsPage />}
          {currentTab === "import" && <ImportPage />}
          {currentTab === "compare" && <ComparePage />}
          {currentTab === "history" && <HistoryPage />}
          {currentTab === "sync" && <SyncPage />}
          {currentTab === "users" && <UsersPage />}
          {currentTab === "trash" && <TrashPage />}
          {currentTab === "settings" && <SettingsPage />}
        </main>
      </div>
    </div>
  );
};
