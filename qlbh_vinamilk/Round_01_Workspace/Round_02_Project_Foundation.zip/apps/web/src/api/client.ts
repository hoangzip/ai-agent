/**
 * File: apps/web/src/api/client.ts
 * API Client kết nối Backend Cloudflare Workers
 */

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  meta?: Record<string, any>;
}

const RAW_BASE = import.meta.env?.VITE_API_BASE_URL as string | undefined;
export const API_BASE_URL = (RAW_BASE && RAW_BASE.trim() !== "" ? RAW_BASE.trim() : "/api").replace(/\/$/, "");

export async function fetchApi<T = any>(endpoint: string, options: RequestInit = {}): Promise<ApiResponse<T>> {
  const cleanEndpoint = endpoint.startsWith("/") ? endpoint : `/${endpoint}`;
  const url = `${API_BASE_URL}${cleanEndpoint}`;
  const headers = new Headers(options.headers || {});
  if (!headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  try {
    const res = await fetch(url, {
      credentials: "include",
      ...options,
      headers
    });
    const json = await res.json();
    return json;
  } catch (err: any) {
    return {
      success: false,
      error: {
        code: "NETWORK_ERROR",
        message: "Không thể kết nối đến máy chủ API: " + (err?.message || String(err))
      }
    };
  }
}

export const api = {
  getHealth: () => fetchApi("/health"),
  getSystemInfo: () => fetchApi("/v1/system/info"),
  getSnapshots: (params: { page?: number; limit?: number; date?: string; store_code?: string } = {}) => {
    const query = new URLSearchParams();
    if (params.page) query.set("page", params.page.toString());
    if (params.limit) query.set("limit", params.limit.toString());
    if (params.date) query.set("date", params.date);
    if (params.store_code) query.set("store_code", params.store_code);
    return fetchApi(`/v1/snapshots?${query.toString()}`);
  }
};
