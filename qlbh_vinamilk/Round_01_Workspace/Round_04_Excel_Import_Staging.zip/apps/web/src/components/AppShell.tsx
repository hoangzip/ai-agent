import React, { useState } from "react";
import { Sidebar, NavItemKey } from "./Sidebar";
import { Header } from "./Header";
import { DashboardPage } from "../pages/DashboardPage";
import { UserManagementPage } from "../pages/UserManagementPage";
import { LoginPage } from "../pages/LoginPage";
import { ChangePasswordModal } from "./ChangePasswordModal";
import { useAuth } from "../context/AuthContext";
import { SnapshotsPage } from "../pages/SnapshotsPage";
import { ImportPage } from "../pages/ImportPage";
import {
  ComparePage,
  HistoryPage,
  SyncPage,
  TrashPage,
  SettingsPage
} from "../pages/OtherPages";

export const AppShell: React.FC = () => {
  const { currentUser, isLoading } = useAuth();
  const [currentTab, setCurrentTab] = useState<NavItemKey>("dashboard");

  const tabTitles: Record<NavItemKey, { title: string; subtitle: string }> = {
    dashboard: {
      title: "Tổng quan Tồn kho",
      subtitle: "Bảng điều khiển theo dõi số liệu và biến động kiểm kê"
    },
    snapshots: {
      title: "Danh sách Chứng từ Kiểm kê",
      subtitle: "Tra cứu các đợt kiểm đếm theo ngày, ca và cửa hàng"
    },
    import: {
      title: "Nhập File Excel Kiểm kê",
      subtitle: "Nạp và chuẩn hóa dữ liệu từ file Excel .xlsx 15 cột"
    },
    compare: {
      title: "So sánh Đối soát Tồn kho",
      subtitle: "Phân tích chênh lệch số lượng và thành tiền giữa hai snapshot"
    },
    history: {
      title: "Lịch sử Biến động Sản phẩm",
      subtitle: "Theo dõi chuỗi thời gian tồn kho của từng SKU"
    },
    sync: {
      title: "Đồng bộ Google Drive",
      subtitle: "Cấu hình tự động quét folder và đối soát dữ liệu đám mây"
    },
    users: {
      title: "Quản lý Người dùng & Phân quyền",
      subtitle: "Quản lý tài khoản, trạng thái khóa và phân quyền RBAC (Chỉ Admin)"
    },
    trash: {
      title: "Thùng rác & Phục hồi",
      subtitle: "Quản lý các snapshot đã xóa mềm (Soft Delete)"
    },
    settings: {
      title: "Cài đặt Hệ thống",
      subtitle: "Tham số kiểm kê, múi giờ và cấu hình vận hành"
    }
  };

  // Loading spinner khi kiểm tra phiên ban đầu
  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="w-10 h-10 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mb-3"></div>
        <p className="text-xs text-slate-500 font-medium">Đang kiểm tra phiên làm việc...</p>
      </div>
    );
  }

  // Nếu chưa đăng nhập, hiển thị trang Đăng nhập
  if (!currentUser) {
    return <LoginPage />;
  }

  const currentInfo = tabTitles[currentTab];

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Modal Bắt buộc đổi mật khẩu lần đầu */}
      <ChangePasswordModal isOpen={currentUser.must_change_password} />

      {/* Sidebar navigation */}
      <Sidebar currentTab={currentTab} onTabChange={setCurrentTab} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header title={currentInfo.title} subtitle={currentInfo.subtitle} />

        <main className="flex-1 overflow-y-auto p-6">
          {currentTab === "dashboard" && <DashboardPage />}
          {currentTab === "snapshots" && <SnapshotsPage />}
          {currentTab === "import" && <ImportPage />}
          {currentTab === "compare" && <ComparePage />}
          {currentTab === "history" && <HistoryPage />}
          {currentTab === "sync" && <SyncPage />}
          {currentTab === "users" && <UserManagementPage />}
          {currentTab === "trash" && <TrashPage />}
          {currentTab === "settings" && <SettingsPage />}
        </main>
      </div>
    </div>
  );
};
