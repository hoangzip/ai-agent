# BÁO CÁO KIỂM THỬ TỰ ĐỘNG – ROUND 04/10 FIX 02

**Dự án:** Inventory Management – Stock Reconciliation Web App (Vinamilk)  
**Phạm vi:** Round 04/10 – Excel Import, Staging & Batch Validation (Fix 02 Final)  
**Thời điểm thực thi:** 2026-10-11  
**Môi trường:** Node.js v20.18.0 + Miniflare D1 SQLite + Python 3.11 (Pytest)  
**Kết quả tổng quan:** **110/110 KIỂM THỬ ĐẠT (100% PASS)**

---

## 1. Tổng hợp kết quả thực thi

| Bộ kiểm thử | Tổng số test | Đạt (PASS) | Thất bại (FAIL) | Thời gian chạy |
|---|:---:|:---:|:---:|:---:|
| **Node.js Test Suite** (`apps/api/tests/*.test.js`) | 73 | 73 | 0 | ~4.01s |
| - `api.test.js` (Hệ thống, CORS, Error Handling, Staging) | 19 | 19 | 0 | 0.05s |
| - `auth.test.js` (Authentication, PBKDF2, RBAC, Rate Limit) | 31 | 31 | 0 | 0.90s |
| - `inventory.test.js` (Excel Parser, Row 2 Math, Deduplication, Fault Injection, Soft-Delete, Limits) | 23 | 23 | 0 | 3.06s |
| **Python Pytest Suite** (`tests/*.py`) | 37 | 37 | 0 | 0.39s |
| - `test_round_02.py` (Cơ sở kiến trúc & D1 schema) | 14 | 14 | 0 | 0.12s |
| - `test_round_03.py` (Users, Sessions, RBAC) | 7 | 7 | 0 | 0.08s |
| - `test_round_04.py` (Excel 4 file thật, 15 cột, Dòng 2, SKU 0 đầu, D1) | 16 | 16 | 0 | 0.19s |
| **TỔNG CỘNG** | **110** | **110** | **0** | **~4.40s** |

---

## 2. Chi tiết các ca kiểm thử mới (Fix 02 Regression)

### 2.1. Cùng nguyên Buffer nhị phân nhưng khác mã kiểm kê (`full_code`)
- Tải file 1 với mã `KK.CH41551.26.339000`.
- Sử dụng **cùng nguyên `Buffer` XLSX nhị phân** (không re-save, không thay đổi bất kỳ byte nào $\rightarrow$ `file_sha256` giống hệt nhau), tải lên dưới tên file `KK.CH41551.26.888999`.
- **Kết quả:** Trả về HTTP 201 Created. Trong DB có cả 2 record độc lập với 2 ID khác nhau và cùng `file_sha256`.

### 2.2. Cùng mã `full_code` và cùng nội dung nhị phân
- Tải lại file với cùng mã `KK.CH41551.26.339000` và cùng nội dung.
- **Kết quả:** Trả về HTTP 409 `ALREADY_IMPORTED`.

### 2.3. Cùng mã `full_code` nhưng dữ liệu mặt hàng khác nhau
- Tải file có mã `KK.CH41551.26.339000` nhưng nội dung của file khác (`340231`).
- **Kết quả:** Trả về HTTP 409 `CONFLICT`.

### 2.4. Nạp lại mã snapshot đã bị xóa mềm (Soft-deleted Snapshot)
- Tạo một snapshot mẫu `KK.CH41551.26.888111` đã bị xóa mềm (`is_deleted = 1`).
- Thử nạp lại file với cùng mã `KK.CH41551.26.888111`.
- **Kết quả:** Trả về HTTP 409 `SNAPSHOT_SOFT_DELETED` kèm thông báo hướng dẫn người dùng khôi phục từ thùng rác, không gây lỗi unhandled UNIQUE constraint của SQLite.

---

## 3. Xác thực Trực tiếp 4 Tệp Excel Thực tế (`Data Source/Kiem ke/*.xlsx`)

| Tệp tin | Ngày kiểm kê | Mã chứng từ | Số SKU | Tổng SL tồn | Tổng thành tiền (VND) | Lệch toán học |
|---|:---:|:---:|:---:|:---:|:---:|:---:|
| `KiemKe_KK.CH41551.26.339000_20261009.xlsx` | 2026-10-09 | 339000 | 432 | 16,961 | 270,739,477 | 0 (Khớp 100%) |
| `KiemKe_KK.CH41551.26.339513_20261009.xlsx` | 2026-10-09 | 339513 | 432 | 17,090 | 272,476,003 | 0 (Khớp 100%) |
| `KiemKe_KK.CH41551.26.339931_20261010.xlsx` | 2026-10-10 | 339931 | 434 | 17,147 | 275,711,737 | 0 (Khớp 100%) |
| `KiemKe_KK.CH41551.26.340231_20261011.xlsx` | 2026-10-11 | 340231 | 434 | 16,972 | 273,775,891 | 0 (Khớp 100%) |
