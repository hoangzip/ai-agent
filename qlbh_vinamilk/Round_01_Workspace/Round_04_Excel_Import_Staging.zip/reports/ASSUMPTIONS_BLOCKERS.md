# DANH SÁCH GIẢ ĐỊNH & ĐIỂM CHẶN (ASSUMPTIONS & BLOCKERS - ROUND 04 FIX 02)

**Dự án:** Quản lý & Đối soát Tồn kho (Vinamilk)  
**Round:** 04/10 – Excel Import, Staging & Batch Validation (Fix 02 - Snapshot Identity & Deduplication)  
**Ngày cập nhật:** 11/10/2026 (Fix 02 Final)  

---

## 1. CÁC HẠNG MỤC ĐÃ GIẢI QUYẾT TRONG ROUND 04 FIX 02

| Hạng mục | Phát hiện Review Final / Yêu cầu Fix 02 | Giải pháp kỹ thuật đã triển khai & Kiểm chứng | Trạng thái |
|---|---|---|:---:|
| **Snapshot Identity (P1)** | Hai snapshot khác `full_code` nhưng cùng nguyên binary `file_sha256` bị chặn nhầm `ALREADY_IMPORTED`. | Loại bỏ việc dùng hash nhị phân làm định danh toàn cục. Định danh nghiệp vụ duy nhất là `full_code`. Hai snapshot khác `full_code` cùng nguyên `Buffer` XLSX nhị phân được lưu trữ thành 2 record hoàn toàn độc lập trong DB. | **HOÀN THÀNH (100% PASS)** |
| **Quy tắc Trùng lặp Nghiệp vụ** | Định nghĩa chưa phân biệt rành mạch giữa các trường hợp trùng file, trùng mã, và xung đột nội dung. | - Cùng `full_code` + cùng data/binary: `409 ALREADY_IMPORTED`<br>- Cùng `full_code` + khác data: `409 CONFLICT`<br>- Khác `full_code` + cùng data/binary: Được lưu độc lập (Status 201) | **HOÀN THÀNH (100% PASS)** |
| **Soft Delete & Re-import** | Nạp lại mã kiểm kê đã xóa mềm gây lỗi SQLite `UNIQUE constraint failed` không rõ nghĩa. | Kiểm tra cả `is_deleted = 1`. Trả về mã lỗi nghiệp vụ `409 SNAPSHOT_SOFT_DELETED` rõ ràng, hướng dẫn người dùng khôi phục từ thùng rác. Không cho Google Drive tự ý khôi phục snapshot đã xóa. | **HOÀN THÀNH (100% PASS)** |
| **Bảo lưu Fix 01** | Giữ vững cơ chế Staging-first, rollback batch error, và xác thực DB. | Giữ nguyên 100% cơ chế khởi tạo `STAGING`, rollback/cleanup khi batch lỗi, kiểm tra `COUNT(*)`, `SUM(quantity)`, `SUM(total_amount)` từ DB D1 trước khi cho phép `COMPLETED`. | **HOÀN THÀNH (100% PASS)** |

---

## 2. KẾ HOẠCH BÀN GIAO CHO ROUND 05 (STOCK COMPARISON ENGINE)

| Hạng mục | Chi tiết kỹ thuật cần thực hiện ở Round 05 | Trách nhiệm |
|---|---|:---:|
| **Đối soát Hai Snapshot** | So khớp 2 snapshot (ví dụ: Sáng vs Chiều, hoặc Ngày 09 vs Ngày 10) theo SKU và Kho. | Backend Developer |
| **Phát hiện Chênh lệch** | Tính delta số lượng (`delta_qty = audit_qty - book_qty`), phân loại: Khớp, Thừa, Thiếu, Mới xuất hiện, Mất dấu. | Data Engineer |
| **Giao diện So sánh & Báo cáo** | Màn hình trực quan hiển thị danh sách chênh lệch, bộ lọc theo ngành hàng/kho, xuất báo cáo đối soát. | Frontend Developer |

---

## 3. ĐIỂM CHẶN HIỆN TẠI (BLOCKERS)

**KHÔNG CÓ ĐIỂM CHẶN (ZERO BLOCKERS)**. Toàn bộ các vấn đề P1/P2 từ Round 04, Fix 01 và Fix 02 đã được xử lý triệt để, kiểm chứng bằng 110/110 tests tự động (73 Node.js tests + 37 Python Pytest). Sẵn sàng đóng Gate Round 04 để chuyển sang Round 05.
