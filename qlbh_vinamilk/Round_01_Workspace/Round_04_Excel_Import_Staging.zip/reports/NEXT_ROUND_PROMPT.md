# PROMPT CHO ROUND 05/10 – STOCK RECONCILIATION & COMPARISON ENGINE

## 1. Bối cảnh & Kết quả Round 04
- Round 04 đã hoàn tất nghiệm thu và đóng gói toàn bộ chức năng Excel Import, Staging & Batch Validation (Core Engine).
- 4 file kiểm kê chính thức (09/10 - 11/10/2026) đã được nạp thành công vào hệ thống với 100% kiểm tra toán học Dòng 2 đạt chuẩn (chênh lệch = 0), bảo toàn số 0 đầu mã SKU (vd: `02AA15`), và cơ chế chống trùng lặp 3 cấp.

## 2. Mục tiêu Round 05
- **Động cơ Đối soát Tồn kho (Reconciliation & Comparison Engine):**
  - Cho phép người dùng chọn 2 snapshot bất kỳ: Snapshot A (Mốc cơ sở) và Snapshot B (Mốc so sánh).
  - Phân loại biến động:
    - Hàng tăng tồn (Quantity Increase).
    - Hàng giảm tồn (Quantity Decrease).
    - Hàng biến động giá (Price Changed).
    - Hàng mới xuất hiện (New SKU in Snapshot B).
    - Hàng biến mất / hết hàng (Disappeared SKU in Snapshot B).
    - Hàng không đổi (Unchanged).
  - Tính toán chênh lệch số lượng (`delta_qty = B.qty - A.qty`), tỷ lệ biến động (`percentage_change`), và chênh lệch giá trị (`delta_amount = B.total_amount - A.total_amount`).
- **Lịch sử Biến động Sản phẩm (SKU History):**
  - Tra cứu biến động tồn kho và giá bán của một SKU qua chuỗi thời gian của tất cả các snapshot đã nạp.
- **API & Giao diện:**
  - `GET /api/v1/compare?snapshot_a=X&snapshot_b=Y`
  - `GET /api/v1/history/:sku`
  - Giao diện `ComparePage.tsx` và `HistoryPage.tsx` trực quan, bảng lọc, KPI tóm tắt biến động.
- **Tiêu chuẩn kiểm thử:**
  - Viết test tự động Node.js và Pytest đối soát chênh lệch giữa các cặp file thực tế:
    - 339000 vs 339513 (cùng ngày 09/10).
    - 339513 (09/10) vs 339931 (10/10).
    - 339931 (10/10) vs 340231 (11/10).
