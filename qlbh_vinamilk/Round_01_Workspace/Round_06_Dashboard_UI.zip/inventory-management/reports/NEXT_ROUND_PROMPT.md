# ĐỀ XUẤT PROMPT CHO ROUND 07/10 – GOOGLE DRIVE AUTO-SYNC ENGINE

> **LƯU Ý QUAN TRỌNG:** TÀI LIỆU NÀY DÀNH CHO ROUND 07. HIỆN TẠI HỆ THỐNG ĐÃ DỪNG GATE TẠI ROUND 06 FIX 01 ĐỂ CHỜ NGƯỜI DÙNG NGHIỆM THU ĐỘC LẬP. TUYỆT ĐỐI KHÔNG TỰ Ý BẮT ĐẦU ROUND 07 KHI CHƯA CÓ LỆNH.

## 1. Bối cảnh & Kết quả Kế thừa từ Round 06 Fix 01
- Round 06 Fix 01 đã giải quyết dứt điểm lỗi cách ly phạm vi cửa hàng trên Dashboard (P1 Blocker), phân quyền giao diện (Sidebar/AppShell RBAC cho USER vs ADMIN), bản địa hóa 100% tiếng Việt kế toán và placeholder Thùng rác.
- Bộ chọn `SnapshotCombobox` đã được kiểm chứng hoạt động trơn tru vượt mốc 100 dòng (thử nghiệm thành công với fixture 150 snapshots).
- Toàn bộ 155 ca kiểm thử tích hợp và hồi quy đạt 100% PASS.

## 2. Mục tiêu Round 07
- **Google Drive Connector & Auto-Sync Engine:**
  - Tích hợp Google Drive API, quét định kỳ thư mục cấu hình (`1HOsA7gWKghPVUcq2JgUhS9xgiccjp4bk`).
  - Tự động phát hiện các file Excel kiểm kê mới tải lên.
  - Tải file nhị phân và đẩy vào quy trình xác thực Staging của Round 04.
  - Ghi nhận lịch sử đồng bộ vào bảng `sync_runs`.
  - Hỗ trợ thao tác đồng bộ chủ động qua nút *"Đồng bộ ngay"* tại trang `SyncPage`.
