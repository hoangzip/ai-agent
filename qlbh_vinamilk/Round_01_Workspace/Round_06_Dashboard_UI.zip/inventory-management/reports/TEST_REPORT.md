# BÁO CÁO KIỂM THỬ TỰ ĐỘNG & VISUAL SMOKE TEST – ROUND 06 FIX 02

**Dự án:** Inventory Management – Stock Reconciliation Web App (Vinamilk)  
**Phạm vi:** Round 06/10 – Fix 02: Stock Scope Isolation & Dynamic Header Context  
**Thời điểm thực thi:** 2026-10-11  
**Môi trường:** Node.js v20.18.0 + Miniflare D1 SQLite + Python 3.11 (Pytest) + Headless Chrome 154  
**Kết quả tổng quan:** **161/161 KIỂM THỬ ĐẠT (100% PASS) + VISUAL SMOKE TEST PASS**

---

## 1. Tổng hợp kết quả thực thi

| Bộ kiểm thử | Tổng số test | Đạt (PASS) | Thất bại (FAIL) | Thời gian chạy |
|---|:---:|:---:|:---:|:---:|
| **Node.js Test Suite** (`apps/api/tests/*.test.js`) | **105** | **105** | **0** | **~5.06s** |
| - `api.test.js` (Hệ thống, CORS, Error Handling, Staging) | 19 | 19 | 0 | 0.05s |
| - `auth.test.js` (Authentication, PBKDF2, RBAC, Rate Limit) | 31 | 31 | 0 | 0.90s |
| - `inventory.test.js` (Excel Parser, Row 2 Math, Deduplication, Limits, Soft-Delete) | 23 | 23 | 0 | 3.06s |
| - `comparison.test.js` (Comparison Engine, 3 Baselines, History, Fix 01 Regressions) | 18 | 18 | 0 | 0.73s |
| - `round_06_dashboard_combobox.test.js` (Carryover P2 + Fix 01 & Fix 02 Stock Scope Tests) | 14 | 14 | 0 | 0.32s |
| **Python Pytest Suite** (`tests/*.py`) | **56** | **56** | **0** | **~0.55s** |
| - `test_round_02.py` (Cơ sở kiến trúc & D1 schema, 9 menu tiếng Việt) | 14 | 14 | 0 | 0.12s |
| - `test_round_03.py` (Users, Sessions, RBAC) | 7 | 7 | 0 | 0.08s |
| - `test_round_04.py` (Excel 4 file thật, 15 cột, Dòng 2, SKU 0 đầu, D1) | 16 | 16 | 0 | 0.19s |
| - `test_round_05.py` (Ground Truth đối soát 3 cặp snapshot, ngữ nghĩa Fix 01) | 8 | 8 | 0 | 0.20s |
| - `test_round_06.py` (Combobox, Scope Isolation, RBAC, Trash, VN Labels, Fix 02 Tests) | 11 | 11 | 0 | 0.06s |
| **TỔNG CỘNG KIỂM THỬ TỰ ĐỘNG** | **161** | **161** | **0** | **~5.61s** |

---

## 2. Chi tiết các ca kiểm thử mới trong Round 06 Fix 02

### 2.1. TEST P1-01: Cùng cửa hàng khác phạm vi kho (scope_id 1 vs 2) TUYỆT ĐỐI KHÔNG đối soát
- Nạp snapshot 301 (`CH_SCOPE_TEST`, `scope_id = 1`, SL: 1.000).
- Nạp snapshot 302 (`CH_SCOPE_TEST`, `scope_id = 2`, SL: 100).
- Gọi `GET /api/v1/dashboard/stats?store_code=CH_SCOPE_TEST`:
  - `latest_snapshot.scope_id`: `2`.
  - `previous_snapshot`: `null` (bỏ qua snapshot 301 vì khác scope).
  - `trend.has_comparison`: `false`.
  - `trend.delta_quantity`: `0`.
  - `trend.delta_amount_vnd`: `0`.
- **Kết quả:** PASS.

### 2.2. TEST P1-02: Cùng cửa hàng và CÙNG phạm vi kho (scope_id 1) đối soát chuẩn xác
- Nạp thêm snapshot 303 (`CH_SCOPE_TEST`, `scope_id = 1`, SL: 1.050).
- Gọi `GET /api/v1/dashboard/stats?store_code=CH_SCOPE_TEST`:
  - `latest_snapshot.id`: `303` (`scope_id = 1`).
  - `previous_snapshot.id`: `301` (`scope_id = 1`, bỏ qua snapshot 302 có `scope_id = 2`).
  - `trend.has_comparison`: `true`.
  - `trend.delta_quantity`: `50` (1.050 - 1.000).
  - `trend.delta_amount_vnd`: `500.000` đ.
- **Kết quả:** PASS.

### 2.3. TEST P1-03: Phạm vi kho không xác định (scope_id = 99 / -1) chặn biến động
- Nạp snapshot 304 & 305 cho `CH_UNKNOWN_STORE` với `scope_id = 99` (UNKNOWN).
- Gọi `GET /api/v1/dashboard/stats?store_code=CH_UNKNOWN_STORE`:
  - `trend.has_comparison`: `false`.
  - `trend.delta_quantity`: `0`.
  - `trend.scope_status`: `"UNKNOWN_SCOPE"`.
  - `trend.scope_message`: Giải thích tiếng Việt rõ ràng từ chối đối soát tự động.
- **Kết quả:** PASS.

### 2.4. TEST P1-04: Đa snapshot trong cùng ngày sắp xếp theo thứ tự ca & thời gian
- Nạp snapshot 306 (ngày 2026-10-20, ca Sáng 08:00, SL: 100) và 307 (ngày 2026-10-20, ca Tối 20:00, SL: 120).
- Gọi `GET /api/v1/dashboard/stats?store_code=CH_SAMEDAY`:
  - `latest_snapshot.id`: `307` (ca Tối).
  - `previous_snapshot.id`: `306` (ca Sáng).
  - `trend.has_comparison`: `true`.
  - `trend.delta_quantity`: `20` (120 - 100).
- **Kết quả:** PASS.

### 2.5. TEST P2-01 & P2-02 (Pytest 10 & 11)
- `test_10_stock_scope_isolation_fix02`: Kiểm tra backend `inventoryService.ts` bảo toàn nghiêm ngặt `scope_id`, `isSameScope`, `isUnknownScope`.
- `test_11_header_context_and_cleanup_fix02`: Kiểm tra Header động theo `storeScope`, không còn viết cứng `CH41551`, không còn nhãn kỹ thuật `Round 03 Auth & RBAC`.
- **Kết quả:** PASS.

---

## 3. Kết quả Visual Smoke Test trên Dev Server (localhost:5173)

- **Công cụ:** Google Chrome Headless 154 (kết nối trực tiếp dev server cổng 5173).
- **Trạng thái stylesheet:** Tải thành công 100% utility classes Tailwind CSS (CSS size: 49.270 bytes).
- **Danh sách ảnh nghiệm thu UI:**
  1. `reports/r06_fix02_login_screenshot.png`: Form đăng nhập Vinamilk chuẩn thiết kế.
  2. `reports/r06_fix02_admin_dashboard.png`: Dashboard Quản trị viên (Sidebar flex, full menu Admin, Header dynamic, 4 thẻ KPI, Quick compare banner).
  3. `reports/r06_fix02_store_selected.png`: Dashboard khi chọn cửa hàng CH41551 (Header tự động đổi sang `Chi nhánh: CH41551`).
  4. `reports/r06_fix02_user_dashboard.png`: Dashboard Nhân viên (Sidebar ẩn 100% menu Admin, huy hiệu Nhân viên màu xanh).
