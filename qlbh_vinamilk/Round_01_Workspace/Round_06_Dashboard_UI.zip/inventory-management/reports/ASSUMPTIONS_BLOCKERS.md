# DANH SÁCH GIẢ ĐỊNH & ĐIỂM CHẶN (ASSUMPTIONS & BLOCKERS – ROUND 06 FIX 02)

**Dự án:** Quản lý & Đối soát Tồn kho (Vinamilk)  
**Round:** 06/10 – Fix 02: Stock Scope Isolation & Dynamic Header Context  
**Ngày cập nhật:** 11/10/2026  

---

## 1. CÁC HẠNG MỤC ĐÃ GIẢI QUYẾT TRONG ROUND 06 FIX 02

| Hạng mục | Yêu cầu Kỹ thuật / Độc lập Review | Kết quả Triển khai | Trạng thái |
|---|---|---|:---:|
| **P1: Phân lập Phạm vi Kho trên Dashboard (Stock Scope Isolation - BLOCKER)** | `getDashboardStats()` phải kiểm tra đồng thời cả `store_code` và `scope_id`. Cùng cửa hàng nhưng khác scope không được đối soát. Phạm vi không xác định (-1, 99) không tự kết luận so sánh được; xử lý có chủ đích và thông báo tiếng Việt. Không sửa database production. | Đã sửa triệt để backend `getDashboardStats`: yêu cầu cùng store VÀ cùng scope_id; chặn kho khác nhau và scope không xác định; hiển thị `scope_message` tiếng Việt chi tiết; bổ sung 4 test Node.js và 1 test Pytest. Database schema production giữ nguyên 100%. | **HOÀN THÀNH (100% PASS)** |
| **P2: Header đúng ngữ cảnh & Bỏ nhãn kỹ thuật** | Gỡ mã chi nhánh `CH41551` viết cứng khỏi Header. Khi người dùng chọn cửa hàng, Header và KPI nhất quán về phạm vi; khi chọn tự động/toàn hệ thống thì nhãn nêu rõ quy tắc thực tế, không tạo ấn tượng cộng dồn nhiều cửa hàng. Bỏ nhãn kỹ thuật `Round 03 Auth & RBAC`. | Header gỡ hoàn toàn `CH41551` và nhãn `Round 03 Auth & RBAC`. Lắng nghe sự kiện đồng bộ từ Dashboard: hiển thị `Chi nhánh: CH41551` khi chọn cửa hàng; hiển thị `Phạm vi: Tự động (Theo đợt mới nhất)` khi ở chế độ toàn hệ thống. | **HOÀN THÀNH (100% PASS)** |
| **CSS/UI: Sửa lỗi hiển thị UI trên Dev Server (localhost:5173)** | Khắc phục hiện tượng mở trang web bị lỗi CSS thô (như ảnh người dùng gửi). Không làm hỏng Tailwind/PostCSS/Vite. Smoke test trực tiếp trên Chrome và chụp ảnh giao diện thực tế. | Cấu hình đường dẫn tuyệt đối cho PostCSS & Tailwind (`apps/web/postcss.config.js`, `vite.config.ts`), bổ sung config gốc; sửa lỗi vi phạm Rules of Hooks trong `DashboardPage.tsx`. Visual smoke test trên Chrome 154 xác nhận giao diện đẹp mắt 100%, có ảnh chụp Admin, User và Store selected. | **HOÀN THÀNH (100% PASS)** |

---

## 2. KẾ HOẠCH BÀN GIAO CHO ROUND 07 (GOOGLE DRIVE AUTO-SYNC ENGINE)

| Hạng mục | Chi tiết kỹ thuật cần thực hiện ở Round 07 | Trách nhiệm |
|---|---|---|
| **Google Drive Connector** | Kết nối Google Drive API (Folder ID: `1HOsA7gWKghPVUcq2JgUhS9xgiccjp4bk`), quét định kỳ các file Excel kiểm kê mới. | Backend Developer |
| **Auto-Sync & Queue Staging** | Tự động phát hiện file mới, tải file nhị phân về và đẩy vào quy trình Staging tự động của Round 04. | Data Engineer |
| **Quản lý Nhật ký Đồng bộ** | Ghi nhận bảng `sync_runs`, trạng thái file đã tải/bỏ qua/trùng lặp/lỗi, cảnh báo xung đột. | Fullstack Developer |

---

## 3. ĐIỂM CHẶN HIỆN TẠI (BLOCKERS)

**KHÔNG CÓ ĐIỂM CHẶN (ZERO BLOCKERS)**.  
Toàn bộ yêu cầu Fix 02 và kiểm thử hồi quy của Round 06 đã được kiểm chứng và hoàn tất:
- **161/161 tests tự động PASS** (105 Node.js tests + 56 Python Pytest).
- Clean TypeScript build & Vite build trên toàn monorepo (`npm run build`).
- Visual smoke test xác nhận CSS dev server và UI layout hoạt động hoàn hảo.
- Dừng Gate tại Round 06, chờ Người dùng nghiệm thu trước khi chuyển tiếp sang Round 07.
