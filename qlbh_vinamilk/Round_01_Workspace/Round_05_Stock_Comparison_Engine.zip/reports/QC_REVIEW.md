# BÁO CÁO ĐÁNH GIÁ CHẤT LƯỢNG (QC REVIEW) – ROUND 05 FIX 01

**Dự án:** Inventory Management – Stock Reconciliation Web App (Vinamilk)  
**Vòng đánh giá:** Round 05/10 Fix 01 – Stock Reconciliation & Comparison Engine  
**Ngày đánh giá:** 2026-10-11  
**Đơn vị thực hiện:** QC Reviewer & Architecture Committee  
**Kết luận Gate:** **PASS – HOÀN TẤT ROUND 05 FIX 01 (DỪNG CHỜ NGHIỆM THU ĐÓNG GATE)**

---

## 1. Mục tiêu và Kết quả Xử lý các Findings (Fix 01)

| Hạng mục | Phát hiện Independent Review Round 05 | Kết quả Xử lý trong Fix 01 | Đánh giá QC |
|---|---|---|:---:|
| **P1-01: Snapshot Status** | Snapshot `STAGING`/`FAILED` có thể tham gia so sánh do chỉ kiểm tra `is_deleted = 0`. | Bắt buộc kiểm tra `status === 'COMPLETED'` ở cả hai snapshot A và B. Trả về HTTP 422 `SNAPSHOT_NOT_COMPLETED` kèm thông báo chi tiết khi snapshot chưa hoàn tất. UI bộ chọn lọc chỉ hiển thị snapshot COMPLETED. | **ĐẠT (100% PASS)** |
| **P1-02: Phân biệt Vắng mặt vs Hết tồn** | SKU có ở A nhưng vắng mặt ở B bị gán nhầm là «Hết tồn» và `target_quantity = 0`. | Phân biệt rạch ròi trạng thái: `NOT_PRESENT` («Không xuất hiện ở kỳ B», `target_quantity: null`, `delta_quantity: null`, `delta_amount: null`) đối với SKU vắng mặt; và `OUT_OF_STOCK` («Hết tồn (SL = 0)», `target_quantity: 0`) đối với SKU có dòng tại B nhưng số lượng = 0. Giữ nguyên 100% Ground Truth 3 cặp baseline. | **ĐẠT (100% PASS)** |
| **P1-03: Cách ly Lịch sử & Cảnh báo Phạm vi** | Lịch sử SKU trừ delta chéo các cửa hàng; thiếu cảnh báo khi so sánh 2 snapshot khác cửa hàng. | Chuỗi lịch sử SKU phân nhóm và tính delta độc lập theo `(store_code, warehouse)`, không trừ chéo cửa hàng. Khi so sánh hai snapshot khác `store_code`, trả về `scope_warning` và hiển thị banner cảnh báo tiếng Việt nổi bật trên UI. | **ĐẠT (100% PASS)** |
| **P2-01: Xuất CSV không bị cắt dòng** | API xuất CSV bị giới hạn ngầm ở 1.000 dòng dữ liệu do áp dụng phân trang của UI. | Bổ sung cờ `fetchAll: true` trong `compareSnapshots()`, cho phép xuất toàn bộ dữ liệu thỏa bộ lọc mà không bị cắt dòng. Kiểm chứng thành công với tập dữ liệu 1.050 SKU. | **ĐẠT (100% PASS)** |
| **P2-02: Chống Formula Injection** | Các ô text bắt đầu bằng `=`, `+`, `-`, `@` trong CSV chưa được khử công thức bảng tính. | Hiện thực hàm `sanitizeCsvText()`, tự động chèn tiền tố `'` trước các ký tự kích hoạt công thức trên các trường text, đồng thời bảo toàn định dạng số nguyên bản cho các cột số lượng/thành tiền/biến động âm. | **ĐẠT (100% PASS)** |

---

## 2. Bảng Đối soát Ground Truth (Khớp 100% với Đánh giá Độc lập)

Xác nhận tính toán độc lập và kiểm thử tự động trên 4 file Excel thật tại `Data Source/Kiem ke/`:

| Cặp Snapshot Đối soát | Tăng | Giảm | Không đổi | Mới | Vắng mặt (Mất) | Biến động SL ($\Delta \text{SL}$) | Biến động Giá trị ($\Delta \text{VND}$) |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **339000 $\rightarrow$ 339513** (09/10 ca 1 $\rightarrow$ ca 2) | 19 | 58 | 355 | 0 | 0 | **+129** | **+1,736,526 VNĐ** |
| **339513 $\rightarrow$ 339931** (09/10 ca 2 $\rightarrow$ 10/10) | 18 | 42 | 372 | 2 | 0 | **+57** | **+3,235,734 VNĐ** |
| **339931 $\rightarrow$ 340231** (10/10 $\rightarrow$ 11/10) | 0 | 28 | 406 | 0 | 0 | **-175** | **-1,935,846 VNĐ** |

*Ghi chú:*
- Cặp 2: Phát hiện đúng 2 SKU mới (`02AO18` Kho hàng bán: 10, `9NH277` Kho KM: 4). Có 2 SKU giảm về 0 tồn kho (`03CA24`, `07VQ11`).
- Cặp 3: Khớp chuẩn xác 5 mã mẫu giảm mạnh: `07KD12` (-24), `04FT32` (-21), `07NH12` (-19), `04EC33` (-16), `07TR33` (-12). Có 2 SKU giảm về 0 tồn kho (`04TT24`, `07FC11`).

---

## 3. Tổng kết Kiểm thử Tự động (Automated Verification)

- **Tổng số test cases:** **136/136 PASS (100%)**
  - **Node.js Integration Tests:** **91/91 PASS** (18 test cases cho Comparison Engine, bao gồm 5 test cases regression chuyên sâu cho P1-01, P1-02, P1-03, P2-01, P2-02).
  - **Python Pytest Suite:** **45/45 PASS** (8 test cases đối soát toán học và ngữ nghĩa trên 4 file Excel gốc).
- **TypeScript Typecheck:** 0 lỗi trên cả 3 package (`shared`, `api`, `web`).
- **Frontend Production Build:** Build Vite thành công (`dist/index.html`, `dist/assets/index.js`, `dist/assets/index.css`).
- **An toàn tệp:** 4 file Excel nguồn nguyên vẹn, không thao tác Git, không chạm DB production.

---

## 4. Quyết định Gate & Hướng dẫn Tiếp theo

- **Quyết định:** **PASS TOÀN DIỆN ROUND 05 FIX 01.**
- **Lệnh dừng:** Tạm dừng triển khai Round 06 theo đúng quy định. Đóng gói bàn giao `Round_05_Stock_Comparison_Engine.zip` kèm mã băm SHA256 và chờ Người dùng kiểm tra, nghiệm thu trước khi chuyển sang Round 06 (Google Drive Auto-Sync Engine).
