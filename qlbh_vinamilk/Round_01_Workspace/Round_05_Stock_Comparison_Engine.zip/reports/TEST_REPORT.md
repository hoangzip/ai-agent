# BÁO CÁO KIỂM THỬ TỰ ĐỘNG – ROUND 05 FIX 01

**Dự án:** Inventory Management – Stock Reconciliation Web App (Vinamilk)  
**Phạm vi:** Round 05/10 Fix 01 – Stock Reconciliation & Comparison Engine  
**Thời điểm thực thi:** 2026-10-11  
**Môi trường:** Node.js v20.18.0 + Miniflare D1 SQLite + Python 3.11 (Pytest)  
**Kết quả tổng quan:** **136/136 KIỂM THỬ ĐẠT (100% PASS)**

---

## 1. Tổng hợp kết quả thực thi

| Bộ kiểm thử | Tổng số test | Đạt (PASS) | Thất bại (FAIL) | Thời gian chạy |
|---|:---:|:---:|:---:|:---:|
| **Node.js Test Suite** (`apps/api/tests/*.test.js`) | 91 | 91 | 0 | ~4.74s |
| - `api.test.js` (Hệ thống, CORS, Error Handling, Staging) | 19 | 19 | 0 | 0.05s |
| - `auth.test.js` (Authentication, PBKDF2, RBAC, Rate Limit) | 31 | 31 | 0 | 0.90s |
| - `inventory.test.js` (Excel Parser, Row 2 Math, Deduplication, Limits, Soft-Delete) | 23 | 23 | 0 | 3.06s |
| - `comparison.test.js` (Comparison Engine, 3 Baselines, History, Fix 01 Regressions) | 18 | 18 | 0 | 0.73s |
| **Python Pytest Suite** (`tests/*.py`) | 45 | 45 | 0 | ~0.59s |
| - `test_round_02.py` (Cơ sở kiến trúc & D1 schema) | 14 | 14 | 0 | 0.12s |
| - `test_round_03.py` (Users, Sessions, RBAC) | 7 | 7 | 0 | 0.08s |
| - `test_round_04.py` (Excel 4 file thật, 15 cột, Dòng 2, SKU 0 đầu, D1) | 16 | 16 | 0 | 0.19s |
| - `test_round_05.py` (Ground Truth đối soát 3 cặp snapshot, ngữ nghĩa Fix 01) | 8 | 8 | 0 | 0.20s |
| **TỔNG CỘNG** | **136** | **136** | **0** | **~5.33s** |

---

## 2. Chi tiết các ca kiểm thử mới bổ sung trong Fix 01

### 2.1. P1-01 Regression: Chặn snapshot chưa hoàn tất (`STAGING`, `FAILED`, `CONFLICT`)
- So sánh với Snapshot A ở trạng thái `STAGING` $\rightarrow$ Trả về HTTP 422 `SNAPSHOT_NOT_COMPLETED` kèm thông báo tiếng Việt.
- So sánh với Snapshot B ở trạng thái `FAILED` $\rightarrow$ Trả về HTTP 422 `SNAPSHOT_NOT_COMPLETED`.
- **Kết quả:** PASS.

### 2.2. P1-02 Regression: Phân biệt `NOT_PRESENT` (Không xuất hiện) vs `OUT_OF_STOCK` (Hết tồn SL=0)
- Thiết lập trường hợp Snapshot B vắng mặt `SKU_MISSING` và có dòng `SKU_ZERO` với số lượng = 0.
- `SKU_MISSING`: Phân loại `NOT_PRESENT`, nhãn «Không xuất hiện ở kỳ B», `target_quantity: null`, `delta_quantity: null`.
- `SKU_ZERO`: Phân loại `OUT_OF_STOCK`, nhãn «Hết tồn (SL = 0)», `target_quantity: 0`, `delta_quantity: -10`.
- Summary trả về: `not_present_count: 1`, `out_of_stock_count: 1`.
- **Kết quả:** PASS.

### 2.3. P1-03 Regression: Cách ly phạm vi lịch sử SKU & Cảnh báo đối soát khác cửa hàng
- So sánh giữa Snapshot cửa hàng `CH41551` và Snapshot cửa hàng `CH99999` $\rightarrow$ Trả về `scope_warning` rõ ràng trong summary.
- Tra cứu lịch sử mặt hàng `02AA15` qua các snapshot $\rightarrow$ Điểm kiểm kê thuộc `CH99999` có `delta_quantity: null`, không bị trừ delta chéo với điểm của `CH41551`.
- **Kết quả:** PASS.

### 2.4. P2-01 Regression: Xuất CSV không bị cắt dòng ở 1.000 dòng
- Tạo snapshot kiểm thử với 1.050 SKU.
- Gọi API xuất file CSV đối soát $\rightarrow$ Trả về đầy đủ 1.051 dòng (1 dòng tiêu đề + 1.050 dòng dữ liệu).
- **Kết quả:** PASS.

### 2.5. P2-02 Regression: Chống tấn công Spreadsheet Formula Injection
- Kiểm thử với các dữ liệu đầu vào chứa ký tự nguy hiểm: `=SUM(A1:A10)`, `+calc|cmd!test`, `@MALICIOUS_SKU`, `-KHO_DOC`.
- Trích xuất CSV: Các trường text được vô hiệu hóa công thức bằng cách tự động chèn tiền tố `'`: `"'=SUM(A1:A10)"`, `"'@MALICIOUS_SKU"`.
- Các giá trị số âm hợp lệ ở cột số lượng/thành tiền/biến động giữ nguyên định dạng số (không chèn tiền tố nháy).
- **Kết quả:** PASS.

---

## 3. Tổng kết Chất lượng Bản dựng Frontend & TypeScript

- **TypeScript Monorepo Compilation (`tsc`):** 0 lỗi cảnh báo trên `@inventory/shared`, `@inventory/api`, `@inventory/web`.
- **Vite Web Bundle Production:** Tạo bundle thành công (CSS: 32.76 kB, JS: 309.42 kB).
