# DANH SÁCH GIẢ ĐỊNH & ĐIỂM CHẶN (ASSUMPTIONS & BLOCKERS - ROUND 05 FIX 01)

**Dự án:** Quản lý & Đối soát Tồn kho (Vinamilk)  
**Round:** 05/10 Fix 01 – Stock Reconciliation & Comparison Engine  
**Ngày cập nhật:** 11/10/2026  

---

## 1. CÁC HẠNG MỤC ĐÃ GIẢI QUYẾT TRONG ROUND 05 FIX 01

| Hạng mục | Phát hiện Independent Review / Quy tắc Fix 01 | Kết quả Triển khai | Trạng thái |
|---|---|---|:---:|
| **P1-01: Snapshot Status** | Chỉ cho phép snapshot COMPLETED tham gia so sánh; chặn STAGING, FAILED, CONFLICT. | Bắt buộc kiểm tra `status === 'COMPLETED'` ở cả hai snapshot. Trả về HTTP 422 `SNAPSHOT_NOT_COMPLETED`. | **HOÀN THÀNH (100% PASS)** |
| **P1-02: Phân loại Vắng mặt vs Hết tồn** | Phân biệt rạch ròi SKU không xuất hiện (NOT_PRESENT) với SKU có dòng số lượng bằng 0 (OUT_OF_STOCK). | SKU vắng mặt ở B có `target_quantity: null`, `delta_quantity: null`. SKU có dòng số lượng = 0 có `target_quantity: 0`, `delta_quantity = 0 - base`. Giữ nguyên 100% Ground Truth 3 cặp baseline. | **HOÀN THÀNH (100% PASS)** |
| **P1-03: Cách ly Lịch sử & Cảnh báo Phạm vi** | Lịch sử SKU không trừ delta chéo cửa hàng/kho; cảnh báo khi so sánh 2 snapshot khác cửa hàng. | Chuỗi lịch sử phân nhóm theo `(store_code, warehouse)`. Trả về `scope_warning` khi khác cửa hàng và hiển thị banner cảnh báo tiếng Việt trên UI. | **HOÀN THÀNH (100% PASS)** |
| **P2-01: Không cắt dòng khi xuất CSV** | Xuất CSV không bị giới hạn ở 1.000 dòng dữ liệu. | Dùng cờ `fetchAll: true` trong `compareSnapshots()`. Xác thực kiểm thử với 1.050 SKU xuất đủ 1.050 dòng dữ liệu. | **HOÀN THÀNH (100% PASS)** |
| **P2-02: Chống Formula Injection** | Khử mã độc công thức Spreadsheet trên các trường text. | Hàm `sanitizeCsvText()` tự động chèn tiền tố `'` trước `=`, `+`, `-`, `@` trên các ô text; giữ nguyên định dạng số âm hợp lệ ở cột số lượng/thành tiền. | **HOÀN THÀNH (100% PASS)** |

---

## 2. KẾ HOẠCH BÀN GIAO CHO ROUND 06 (GOOGLE DRIVE AUTO-SYNC ENGINE)

| Hạng mục | Chi tiết kỹ thuật cần thực hiện ở Round 06 | Trách nhiệm |
|---|---|:---:|
| **Google Drive Connector** | Kết nối Google Drive API (Service Account / OAuth2), lắng nghe hoặc quét folder chứa file Excel kiểm kê. | Backend Developer |
| **Auto-Sync & Queue Staging** | Tự động phát hiện file mới, tải file về và đẩy vào quy trình Staging của Round 04. | Data Engineer |
| **Quản lý Lịch sử Đồng bộ** | Ghi nhận nhật ký đồng bộ, trạng thái file đã tải/bỏ qua/lỗi, cảnh báo xung đột. | Fullstack Developer |

---

## 3. ĐIỂM CHẶN HIỆN TẠI (BLOCKERS)

**KHÔNG CÓ ĐIỂM CHẶN (ZERO BLOCKERS)**.  
Toàn bộ 3 lỗi P1 và 2 vấn đề P2 từ Independent Review đã được khắc phục hoàn chỉnh:
- 136/136 tests tự động PASS (91 Node.js tests + 45 Python Pytest).
- Clean TypeScript build trên toàn monorepo (`tsc && vite build`).
- Dừng Gate tại Round 05 Fix 01, chờ Người dùng nghiệm thu trước khi bước sang Round 06.
